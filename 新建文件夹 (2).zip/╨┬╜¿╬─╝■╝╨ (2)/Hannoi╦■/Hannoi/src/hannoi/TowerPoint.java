/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hannoi;

/**
 *
 * @author Administrator
 */
import java.awt.*;
public class TowerPoint 
{
    int x,y;
    boolean 有盘子;
    Disk 盘子=null;
    HannoiTower con=null;
    public TowerPoint(int x,int y,boolean boo)
    {
        this.x=x;
        this.y=y;
        有盘子=boo;
    }
    public boolean 是否有盘子()
    {
        return 有盘子;
    }
    public void set有盘子(boolean boo)
    {
        有盘子=boo;
    }
    public int getX()
    {
        return x;
    }
    public int getY()
    {
        return y;
    }
    public void 放置盘子(Disk 盘子,HannoiTower con)
    {
        this.con=con;
        con.setLayout(null);
        this.盘子=盘子;
        con.add(盘子);
        int w=盘子.getBounds().width;
        int h=盘子.getBounds().height;
        盘子.setBounds(x-w/2,y-h/2,w,h);
        有盘子=true;
        con.validate();
    }
    public Disk 获取盘子()
    {
        return 盘子;
    }

}
