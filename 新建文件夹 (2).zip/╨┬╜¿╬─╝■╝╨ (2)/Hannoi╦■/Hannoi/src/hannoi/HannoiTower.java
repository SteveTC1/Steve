/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hannoi;

/**
 *
 * @author Administrator
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class HannoiTower extends JPanel implements MouseListener,MouseMotionListener
{
   TowerPoint point[];                                          
   int x,y;                                                     
   boolean move=false;                                         
   Disk   盘子[];                                              
   int startX,startY;                                          
   int startI ;                                                
   int 盘子数目=0;
   int width,height;                                           
   char towerName[]={'A','B','C'};                            
   TextArea 信息条=null;                                      

   public  HannoiTower(int number,int w,int h,char[] name,TextArea text)
   {
        towerName=name;
        盘子数目=number;
        width=w;
        height=h;
        信息条=text;
        setLayout(null);
        addMouseListener(this);
        addMouseMotionListener(this);
        盘子= new Disk[盘子数目];
        point=new TowerPoint[3*盘子数目];                         
         int space=20;  
        for(int i=0;i<盘子数目;i++)                               
          {
            point[i]=new TowerPoint(40+width,100+space,false); 
            space=space+height;
          }
        space=20;
        for(int i=盘子数目;i<2*盘子数目;i++)                        
          {
            point[i]=new TowerPoint(160+width,100+space,false);
            space=space+height;
          }
        space=20;
        for(int i=2*盘子数目;i<3*盘子数目;i++)                     
          {
            point[i]=new TowerPoint(280+width,100+space,false);
            space=space+height;
          }
       int tempWidth=width;                                      
       int sub=(int)(tempWidth*0.2);
       for(int i=盘子数目-1;i>=0;i--)                            
          {
             盘子[i]=new Disk(i,this);
             盘子[i].setSize(tempWidth,height);                   
             tempWidth=tempWidth-sub;
          }
        for(int i=0;i<盘子数目;i++)                             
          {
            point[i].放置盘子(盘子[i],this);
            if(i>=1)
            盘子[i].set上方有盘(true); 
          }
    }
  public void paintComponent(Graphics g)                     
   {
     super.paintComponent(g);
     g.drawLine(point[0].getX(),point[0].getY(),
                point[盘子数目-1].getX(),point[盘子数目-1].getY());     
     g.drawLine(point[盘子数目].getX(),point[盘子数目].getY(),
                point[2*盘子数目-1].getX(),point[2*盘子数目-1].getY()); 
     g.drawLine(point[2*盘子数目].getX(),point[2*盘子数目].getY(),
                point[3*盘子数目-1].getX(),point[3*盘子数目-1].getY()); 
     g.drawLine(point[盘子数目-1].getX()-width,point[盘子数目-1].getY(),
               point[3*盘子数目-1].getX()+width,point[3*盘子数目-1].getY()); 
     int leftx=point[盘子数目-1].getX()-width;
     int lefty=point[盘子数目-1].getY();
     int w=(point[3*盘子数目-1].getX()+width)-(point[盘子数目-1].getX()-width);
     int h=height/2;
     g.setColor(Color.orange);
     g.fillRect(leftx,lefty,w,h);
     
     g.setColor(Color.red);
     int size=4;
     for(int i=0;i<3*盘子数目;i++)                                    
       {
         g.fillOval(point[i].getX()-size/2,point[i].getY()-size/2,size,size);
       }
     g.drawString(""+towerName[0]+"塔",point[盘子数目-1].getX(),point[盘子数目-1].getY()+30);
     g.drawString(""+towerName[1]+"塔",point[2*盘子数目-1].getX(),point[盘子数目-1].getY()+30);
     g.drawString(""+towerName[2]+"塔",point[3*盘子数目-1].getX(),point[盘子数目-1].getY()+30);
     
     g.drawString("将全部盘子从"+towerName[0]+"塔搬运到"+towerName[1]+"塔或"+towerName[2]+"塔",
                  point[盘子数目-1].getX(),point[盘子数目-1].getY()+80);        
   } 
  public void mousePressed(MouseEvent e)
  { 
    Disk  盘子=null;
    Rectangle rect=null;
    if(e.getSource()==this)                                 
        move=false;
    if(move==false)
      if(e.getSource() instanceof Disk)
       {
         盘子=(Disk)e.getSource();                          
         startX=盘子.getBounds().x;                         
         startY=盘子.getBounds().y;     
         
          rect=盘子.getBounds();
          for(int i=0;i<3*盘子数目;i++)   
            {
               int x=point[i].getX();
               int y=point[i].getY();
                  if(rect.contains(x,y))
                   {                   
                     startI=i;                            
                     break;
                   }
            }
       }
  } 
 public void mouseMoved(MouseEvent e)
  { 
  }
 public void mouseDragged(MouseEvent e)
  {
 
    Disk disk=null;
       if(e.getSource() instanceof Disk)
         {
           disk=(Disk)e.getSource();                        
           move=true; 
           
           e=SwingUtilities.convertMouseEvent(disk,e,this); 
         }
    
       if(e.getSource()==this)
        {
          if(move&&disk!=null)
           {
            x=e.getX(); 
            y=e.getY();
            if(disk.get上方有盘()==false)
               disk.setLocation(x-disk.getWidth()/2,y-disk.getHeight()/2);
           }
        }
 }
 public void mouseReleased(MouseEvent e)
  { 
    Disk disk=null;
    move=false;
    Rectangle rect=null;
    if(e.getSource() instanceof Disk)
      {
        disk=(Disk)e.getSource();                            
        rect=disk.getBounds();
         
        e=SwingUtilities.convertMouseEvent(disk,e,this);    
      }
    if(e.getSource()==this)
     {
        boolean containTowerPoint=false;
        int x=0,y=0;
        int endI=0;
        if(disk!=null)
         { 
          for(int i=0;i<3*盘子数目;i++)
            {
                x=point[i].getX();
                y=point[i].getY();
                if(rect.contains(x,y))
                   { 
                     containTowerPoint=true;
                     endI=i;
                     break;
                  }
            }
         }
        if(disk!=null&&containTowerPoint)
         {
         
           if(point[endI].是否有盘子()==true)        
             { 
               disk.setLocation(startX,startY);                        
             } 
          else
             {
 
                if(endI==盘子数目-1||endI==2*盘子数目-1||endI==3*盘子数目-1)  
                 { 
                  point[endI].放置盘子(disk,this);                       
                  
                  if(startI!=盘子数目-1&&startI!=2*盘子数目-1&&startI!=3*盘子数目-1)
                    {
                     (point[startI+1].获取盘子()).set上方有盘(false);
                     point[startI].set有盘子(false);     
                    }
                  else
                    {
                       point[startI].set有盘子(false);  
                    } 
                 } 
                else 
                 { 
                   if(point[endI+1].是否有盘子()==true)
                    {
                      Disk tempDisk=point[endI+1].获取盘子();
                      if((tempDisk.getNumber()-disk.getNumber())>=1)
                       {
                        point[endI].放置盘子(disk,this);                
                         if(startI!=盘子数目-1&&startI!=2*盘子数目-1&&startI!=3*盘子数目-1)
                          {
                            (point[startI+1].获取盘子()).set上方有盘(false);
                             point[startI].set有盘子(false); 
                             tempDisk.set上方有盘(true);   
                          }
                         else
                          {
                             point[startI].set有盘子(false); 
                             tempDisk.set上方有盘(true); 
                          } 
                       }
                      else
                       {
                         disk.setLocation(startX,startY); 
                       }
                    }
                   else
                    {
                      disk.setLocation(startX,startY);                   
                    }
                 } 
            }
        
                
        }
     if(disk!=null&&!containTowerPoint)        
        {        
          disk.setLocation(startX,startY);
        }
     } 
  }
 public void mouseEntered(MouseEvent e)
  {
  }
 public void mouseExited(MouseEvent e)
  { 
  }
 public void mouseClicked(MouseEvent e)
  { 
  }
 
 public void 自动演示搬运盘子(int 盘子数,char one,char two,char three)
  {
     if(盘子数==1)
       {
         信息条.append(""+one+" 到: "+three+"塔\n");
         Disk disk=在塔中获取最上面的盘子(one);
         int startI=在塔中获取最上面盘子的位置(one);
         int endI=在塔中获取最上面盘子的上方位置(three);                 
         if(disk!=null)
           {
             point[endI].放置盘子(disk,this);
             point[startI].set有盘子(false);
              try{
                  Thread.sleep(1000);                       
                 }
              catch(Exception ee)
                 {
                 }
           }
        }
      else
        {
          自动演示搬运盘子(盘子数-1,one,three,two);
	  信息条.append(""+one+" 到: "+three+"塔\n");
          Disk disk=在塔中获取最上面的盘子(one);
          int startI=在塔中获取最上面盘子的位置(one);
          int endI=在塔中获取最上面盘子的上方位置(three);                 
          if(disk!=null)
            {
             point[endI].放置盘子(disk,this);
             point[startI].set有盘子(false);
             try {
                  Thread.sleep(1000);                       
                 }
              catch(Exception ee)
                 {
                 }
            } 
	  自动演示搬运盘子(盘子数-1,two,one,three);
        }
  }
 public Disk 在塔中获取最上面的盘子(char 塔名)
  {
    Disk disk=null;
    if(塔名==towerName[0])
      {
         for(int i=0;i<盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 disk=point[i].获取盘子();
                 break;
               }
           }  
      }
     if(塔名==towerName[1])
      {
         for(int i=盘子数目;i<2*盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 disk=point[i].获取盘子();
                 break;
               }
           }  
      }
      if(塔名==towerName[2])
      {
         for(int i=2*盘子数目;i<3*盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 disk=point[i].获取盘子();
                 break;
               }
           }  
      }
   return disk;
  } 
 public int 在塔中获取最上面盘子的上方位置(char 塔名)
  {
    int position=0;
    if(塔名==towerName[0])
      {  
         int i=0;
         for(i=0;i<盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 position=Math.max(i-1,0);
                 break;
               }
           } 
         if(i==盘子数目)
           {
             position=盘子数目-1;
           } 
      }
     if(塔名==towerName[1])
      {  
          int i=0;
         for(i=盘子数目;i<2*盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 position=Math.max(i-1,0);
                 break;
               }
           } 
          if(i==2*盘子数目)
           {
             position=2*盘子数目-1;
           }  
      }
      if(塔名==towerName[2])
      {
         int i=0;
         for(i=2*盘子数目;i<3*盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 position=Math.max(i-1,0);
                 break;
               }
           }  
          if(i==3*盘子数目)
           {
             position=3*盘子数目-1;
           }  
      }
    return position;
  } 
  public int 在塔中获取最上面盘子的位置(char 塔名)
  {
    int position=0;
    if(塔名==towerName[0])
      {  
         int i=0;
         for(i=0;i<盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 position=i;
                 break;
               }
           } 
         if(i==盘子数目)
           {
             position=盘子数目-1;
           } 
      }
     if(塔名==towerName[1])
      {  
          int i=0;
         for(i=盘子数目;i<2*盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 position=i;
                 break;
               }
           } 
          if(i==2*盘子数目)
           {
             position=2*盘子数目-1;
           }  
      }
      if(塔名==towerName[2])
      {
         int i=0;
         for(i=2*盘子数目;i<3*盘子数目;i++)
           {
             if(point[i].是否有盘子()==true)
               {
                 position=i;
                 break;
               }
           }  
          if(i==3*盘子数目)
           {
             position=3*盘子数目-1;
           }  
      }
    return position;
  } 
}
