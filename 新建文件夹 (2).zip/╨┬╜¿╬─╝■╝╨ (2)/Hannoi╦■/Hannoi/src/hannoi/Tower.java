/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hannoi;

/**
 *
 * @author Administrator
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Tower extends Frame implements ActionListener,Runnable
{
    HannoiTower tower=null;
    Button renew,auto=null;
    char towerName[]={'A','B','C'};
    int 盘子数目,盘宽,盘高;
    Thread thread;
    TextArea 信息条=null;
    public Tower()
    {
        thread=new Thread(this);
        盘子数目=5;
        盘宽=80;
        盘高=18;
        信息条=new TextArea(12,12);
        信息条.setText(null);
        tower=new HannoiTower(盘子数目,盘宽,盘高,towerName,信息条);
        renew=new Button("重新开始");
        auto=new Button("自动演示搬盘子");
        renew.addActionListener(this);
        auto.addActionListener(this);
        add(tower,BorderLayout.CENTER);
        add(renew,BorderLayout.SOUTH);
        add(auto,BorderLayout.NORTH);
        add(信息条,BorderLayout.EAST);
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing(WindowEvent e)
            {
                System.exit(0);
            }
        });
        setVisible(true);
        setBounds(60,20,670,540);
        validate();
    }
   public void actionPerformed(ActionEvent e)
   {
       if(e.getSource()==renew)
       {
           if(!(thread.isAlive()))
           {
               this.remove(tower);
               信息条.setText(null);
               tower=new HannoiTower(盘子数目,盘宽,盘高,towerName,信息条);
               add(tower,BorderLayout.CENTER);
               validate();
           }
           else
           {
               
           }
       }
       if(e.getSource()==auto)
       {
           if(!(thread.isAlive()))
           {
               thread=new Thread(this);
           }
           try
           {
               thread.start();
           }
           catch(Exception eee)
           {
               
           }
       }
   }
   public void run()
   {
       this.remove(tower);
       信息条.setText(null);
       tower=new HannoiTower(盘子数目,盘宽,盘高,towerName,信息条);
       add(tower,BorderLayout.CENTER);
       validate();
       tower.自动演示搬运盘子(盘子数目,towerName[0],towerName[1],towerName[2]);
   }
   public static void main(String args[])
   {
       new Tower();
   }
}         
