/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hannoi;

/**
 *
 * @author Administrator
 */
import java.io.*;
import java.awt.*;
public class Disk extends Button
{
    int number;
    boolean 上方有盘=false;
    public Disk(int number,HannoiTower con)
    {
        this.number=number;
        setBackground(Color.blue);
        addMouseMotionListener(con);
        addMouseListener(con);
    }
    public boolean get上方有盘()
    {
        return 上方有盘;
    }
    public void set上方有盘(boolean b)
    {
        上方有盘=b;
    }
    public int getNumber()
    {
        return number;
    }

}
