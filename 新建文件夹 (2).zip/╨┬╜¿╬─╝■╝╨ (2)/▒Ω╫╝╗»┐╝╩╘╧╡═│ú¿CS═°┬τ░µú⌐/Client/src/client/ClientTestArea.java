/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package client;

/**
 *
 * @author Administrator
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class ClientTestArea extends Panel implements ActionListener,Runnable
{
  Socket  socket=null;                               
  DataInputStream in=null;                           
  DataOutputStream out=null;                         
  Thread threadMessage=null;                         
  TextArea 试题显示区=null,答案显示区=null;
  Checkbox box[];                                   
  String answer="?";
  long time=0;                                     
  Timer 计时器=null;                  
  Button  提交该题答案,读取下一题,查看得分;
  TextField 考试用时提示条=null;
  public ClientTestArea()
  {
    threadMessage=new Thread(this);                
    试题显示区=new  TextArea("",16,5,TextArea.SCROLLBARS_BOTH);
    答案显示区=new  TextArea("",3,5,TextArea.SCROLLBARS_VERTICAL_ONLY);
    答案显示区.setFont(new Font("TimesRoman",Font.PLAIN,14));
    试题显示区.setFont(new Font("TimesRoman",Font.PLAIN,14));
    试题显示区.setForeground(Color.blue);     
    试题显示区.setText(null);
    答案显示区.setForeground(new Color(255,100,100));     
    答案显示区.setText("单击查看得分按钮,可以在这里看到得分和正确答案"); 

    计时器=new Timer(1000,this);  
    String s[]={"A","B","C","D"};
    box=new Checkbox[4];
    for(int i=0;i<4;i++)
      {
        box[i]=new Checkbox(s[i]);
      }
    提交该题答案=new Button("提交该题答案"); 
    读取下一题=new Button("读取下一题");
    查看得分=new Button("查看得分");
    考试用时提示条=new TextField("显示考试用时(倒计时)",28);
    考试用时提示条.setForeground(Color.red);
    考试用时提示条.setEditable(false);
    读取下一题.setEnabled(true);
    提交该题答案.setEnabled(false);
    读取下一题.setEnabled(false);
    读取下一题.addActionListener(this);
    提交该题答案.addActionListener(this);
    查看得分.addActionListener(this);   
    Panel pAddbox=new Panel();
    for(int i=0;i<4;i++)
      {
        pAddbox.add(box[i]);
      }
    setLayout(new BorderLayout());
    Panel pCenter=new Panel();
    pCenter.setLayout(new BorderLayout());
    pCenter.add(试题显示区,BorderLayout.CENTER);
    pCenter.add(答案显示区,BorderLayout.NORTH);
    add(pCenter,BorderLayout.CENTER);
    Panel p1=new Panel();
    p1.add(pAddbox);
    p1.add(提交该题答案);
    p1.add(读取下一题);
    p1.add(查看得分);
    Panel p2=new Panel();
    p2.add(考试用时提示条);
    Panel  pSouth=new Panel();
    pSouth.setLayout(new GridLayout(2,1));
    pSouth.add(p1);
    pSouth.add(p2);
    add(pSouth,BorderLayout.SOUTH);
   
  }
 public long getTime()
    {
      return time;
    }
 public void setSocketConnection(Socket socket,DataInputStream in,DataOutputStream out)
    {
      this.socket=socket;
      this.in=in;
      this.out=out;
      try{ 
           threadMessage.start();
         }
      catch(Exception e)
         {
         } 
      if(this.socket!=null)
       {
         读取下一题.setEnabled(true);
         提交该题答案.setEnabled(false);
         计时器.stop();
         考试用时提示条.setText("显示考试用时(倒计时)");
       } 
    }
public void set试题显示区(String s)
    {
      试题显示区.setText(s);
    }
public void actionPerformed(ActionEvent e)
  {
    if(e.getSource()==计时器)
       {
         time=time-1000;
         if(time<=0)                            
          {
             计时器.stop();
             读取下一题.setEnabled(false);
             提交该题答案.setEnabled(false);
          }
          long  leftTime=time/1000;               
          long leftHour=leftTime/3600;           
          long leftMinute=(leftTime-leftHour*3600)/60;
          long leftSecond=leftTime%60;           
          考试用时提示条.setText("剩余时间："+leftHour+"小时 "+leftMinute+"分 "+leftSecond+" 秒");
        }
    if(e.getSource()==读取下一题)
       {
         读取下一题.setLabel("读取下一题");
         提交该题答案.setEnabled(true);
         读取下一题.setEnabled(false);
          try {
                out.writeUTF("读取下一题");
              }
          catch(Exception event)
              {
              }
       } 
    if(e.getSource()==提交该题答案)
       {
          读取下一题.setEnabled(true);
          提交该题答案.setEnabled(false);
          for(int i=0;i<4;i++)
             {
               if(box[i].getState()==true)
                  {
                    answer=box[i].getLabel();
                    box[i].setState(false);
                    break;
                  } 
             }
          try
             {         
               out.writeUTF("提交的答案:"+answer);
             }
          catch(IOException ee)
             {
             }
       }
   if(e.getSource()==查看得分)
       { 
          try
             {    
               out.writeUTF("查看得分");
             }
           catch(IOException ee)
             {
             }
       }  
  }
public void run()                    
  {
     while(true)
        {
           String s=null;
            try
               { 
                 s=in.readUTF();               
                 if(s.startsWith("试题内容:")) 
                    {
                      String content=s.substring(s.indexOf(":")+1);
                      试题显示区.setText(s);
                    }
                 if(s.startsWith("分数"))
                    {
                      答案显示区.setText("\n"+s); 
                    }
                 if(s.startsWith("考试用时:"))
                    {
                      String str=s.substring(s.indexOf(":")+1);
                      time=Long.parseLong(str);
                      考试用时提示条.setText(""+time);
                      计时器.start();     
                    }
                  if(s.startsWith("考试结束:"))
                    {
                      计时器.stop();     
                    }
                  
                 Thread.sleep(5); 
               } 
            catch(Exception e)
               {
                  试题显示区.setText("和服务器的连接已中断");
               }
        }
  }
} 
