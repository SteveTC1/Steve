/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package makejpeg;

/**
 *
 * @author Administrator
 */
import java.awt.*;
import java.util.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import com.sun.image.codec.jpeg.*;
class Point
{int x,y;
 Point(int x,int y)
 {this.x=x;this.y=y;
 }
}
public class MakeJPEG extends Canvas implements MouseMotionListener,MouseListener,ActionListener
{  
   int x=-1,y=-1,橡皮擦通知=0,清除通知=0;
   Vector v=null;int n=1;
   Graphics2D  ggg ;                                             
   BufferedImage image;                                          
   Frame window;
   Button 保存,调色板,橡皮,清除,画笔,获取屏幕,绘制图形;
   Color 画笔颜色;
   Panel pCenter,pSouth,pNorth;
  
 public MakeJPEG()
 { 
    保存=new Button("将绘制的图形或屏幕保存为JPG文件");
    获取屏幕=new Button("获取屏幕");
    绘制图形=new Button("绘制图形");
    调色板=new Button("打开调色板");
    画笔=new Button("画笔");
    橡皮=new Button("橡皮");
    清除=new Button("清除");
    调色板.addActionListener(this);
    绘制图形.addActionListener(this);
    保存.addActionListener(this);
    画笔.addActionListener(this);
    橡皮.addActionListener(this);
    清除.addActionListener(this);
    获取屏幕.addActionListener(this);
    画笔颜色=new Color(0,0,0);
    addMouseMotionListener(this); 
    addMouseListener(this);
    v=new Vector(); 
    setBackground(Color.white);                                 
    image=new BufferedImage(200,200,BufferedImage.TYPE_INT_RGB);
    ggg=image.createGraphics();                                 
    Rectangle2D rect=new Rectangle2D.Double(0,0,200,200);      
    ggg.setColor(getBackground());
    ggg.fill(rect);                                             
    window=new Frame("JPEG图像生成器");
    pCenter=new Panel();
    pCenter.setLayout(null);
    pCenter.add(this);
    pCenter.setBackground(Color.gray);
    this.setBounds(80,30,210,210);                              
    window.add(pCenter,BorderLayout.CENTER);
    pNorth=new Panel();
    pNorth.add(保存);
    pNorth.add(绘制图形);
    pNorth.add(获取屏幕);
    window.add(pNorth,BorderLayout.NORTH);
    pSouth=new Panel();
    pSouth.add(调色板);
    pSouth.add(橡皮);
    pSouth.add(清除);
    pSouth.add(画笔);
    window.add(pSouth,BorderLayout.SOUTH);
    window.setVisible(true);
    window.addWindowListener(new WindowAdapter()
                   { 
                     public void windowClosing(WindowEvent e)
                     { 
                        System.exit(0);
      	             }
      	           });
    window.setBounds(100,80,390,380);
    window.validate();                                         
 }
 public void paint(Graphics g)                                 
 {
    if(x!=-1&&y!=-1&&橡皮擦通知==0&&清除通知==0)
     {  
        g.setColor(画笔颜色);
        n=v.size();
        for(int i=0;i<n-1;i++)
         {
           Point p1=(Point)v.elementAt(i); 
           Point p2=(Point)v.elementAt(i+1); 
           g.drawLine(p1.x,p1.y,p2.x,p2.y);                     
           ggg.setColor(g.getColor());
           ggg.drawLine(p1.x,p1.y,p2.x,p2.y);                   
         }
     }
    else if(橡皮擦通知==1&&清除通知==0)
     {
       g.setColor(getBackground());
       g.fillRect(x-2,y-2,4,4);
       ggg.setColor(getBackground());
       ggg.fillRect(x-2,y-2,4,4);
     }
   else if(清除通知==1&&橡皮擦通知==0)
     {
       g.setColor(getBackground());
       g.fillRect(0,0,200,200);
       ggg.setColor(getBackground());
       ggg.fillRect(0,0,200,200);
     }

    g.drawImage(image,0,0,200,200,this);                       
 }
public void mouseDragged(MouseEvent e)
 {  
      x=(int)e.getX();
      y=(int)e.getY();
      Point p=new Point(x,y);
      v.addElement(p);
      repaint();
 }
  public void mouseMoved(MouseEvent e)
  {} 
  public void mousePressed(MouseEvent e)
  {} 
  public void mouseReleased(MouseEvent e)
   {   
      v.removeAllElements();
   }
  public void mouseEntered(MouseEvent e){}
  public void mouseExited(MouseEvent e){}
  public void mouseClicked(MouseEvent e){}
  
  public void update(Graphics g)
  { 
    {
      paint(g);
    }
  } 
  public void actionPerformed(ActionEvent e)
  { 
    if(e.getSource()==橡皮)
       {
         橡皮擦通知=1;
         清除通知=0 ;
       }
    else if(e.getSource()==清除)
       {
         清除通知=1; 
         橡皮擦通知=0;
         repaint();
       }
    else if(e.getSource()==画笔)
    { 
      橡皮擦通知=0;
      清除通知=0;
    }

    else if(e.getSource()==保存)
       {
          FileDialog savedialog=new FileDialog(window,"保存图型到JPG格式",FileDialog.SAVE);

          savedialog.setVisible(true);   
                                         

          if(savedialog.getFile()!=null) 
             {
                try{
                     String fileName=savedialog.getFile();    
                     FileOutputStream out=new FileOutputStream(fileName);
                     
                     JPEGImageEncoder encoder=JPEGCodec.createJPEGEncoder(out);
                     
                     JPEGEncodeParam param=encoder.getDefaultJPEGEncodeParam(image);
                     
                     param.setQuality(1.0f,false);
                     encoder.setJPEGEncodeParam(param);
                     
                     encoder.encode(image);
                     out.close();
                   }
               catch(Exception EE)
                   {
                   } 
             }     
       }
    else if(e.getSource()==获取屏幕)
       {
         Robot robot=null;                               
         try{
             robot=new  Robot();                         
            }
         catch(Exception er)
            {
            }
         Rectangle screenRect=null;                      
         int width=getToolkit().getScreenSize().width;   
         int height=getToolkit().getScreenSize().height; 
         screenRect=new Rectangle(0,0,width,height); 
        
         window.setVisible(false);                       
         this.window.setVisible(false);
         image=robot.createScreenCapture(screenRect);    
         window.setVisible(true);
         repaint();                                      
       }
   else if(e.getSource()==调色板)
       {
         Color tempColor=JColorChooser.showDialog(window,"调色板",画笔颜色);
           {
             if(tempColor!=null)
               {
                 画笔颜色=tempColor;
                 画笔.setForeground(画笔颜色);
               }
           }
       }
   else if(e.getSource()==绘制图形)
       { 
         window.dispose();                                 
         this.window.dispose();
         MakeJPEG canvas=new MakeJPEG();
       }
  }
 public static void main(String args[])
  {
    new MakeJPEG();
  }
}
