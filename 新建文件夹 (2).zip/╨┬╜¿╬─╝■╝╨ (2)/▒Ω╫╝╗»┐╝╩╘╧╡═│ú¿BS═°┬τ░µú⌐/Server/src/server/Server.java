/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server;

/**
 *
 * @author Administrator
 */
import java.io.*;
import java.net.*;
import java.util.*;
class FileName implements FilenameFilter  
{ 
    String str=null;
         FileName (String s)
         {
            str="."+s;
         }
    public  boolean accept(File dir,String name)
         { 
            return name.endsWith(str);
         }              
}

public class Server 
{  
  public static void main(String args[])
    {
     ServerSocket server=null;
     Socket you=null;
     while(true) 
            {
             try
                  { 
                    server=new ServerSocket(6666);
                  }
             catch(IOException e1) 
                  {
                     System.out.println("正在监听");
                  } 
             try  {
                     you=server.accept();          
                     InetAddress address=you.getInetAddress();
                     System.out.println("客户端的IP:"+address);
                     
                  }
             catch (IOException e)
                  {
                  }
             if(you!=null) 
                  {
                     new Server_thread(you).start(); 
                  }
             else {
                    continue;
                  }
           }
  }
}
class Server_thread extends Thread
{  
   int i=0;
   Socket socket=null;
   File file=null;
   DataOutputStream out=null;
   DataInputStream  in=null;
   ReadTestquestion 读取试题=null;
   boolean 通知考试界面考试用时=true;
   Server_thread(Socket t)
       { 
         socket=t;
         try {
               in=new DataInputStream(socket.getInputStream());
               out=new DataOutputStream(socket.getOutputStream());
             }
         catch (IOException e)
             {
             }
         读取试题=new ReadTestquestion();
       }  
 public void run()        
  {  
     
     while(true)
      {    String s=null;   
        try
           {
            s=in.readUTF();                          
            if(s.startsWith("列出考试文件"))        
              {
               String 当前目录=System.getProperty("user.dir");
               File dir=new File(当前目录);
               FileName fileTxt=new FileName("txt");
               String fileName[]=dir.list(fileTxt);   
               for(int i=0;i<fileName.length;i++) 
                  {
                    out.writeUTF("考试文件:"+fileName[i]); 
                  }
                out.writeUTF("已经全部列出:");
              }
            else if(s.startsWith("考试文件的名字:")) 
              {
                String fileName=s.substring(s.indexOf(":")+1);  
                读取试题.setFilename(fileName);
                读取试题.set完成考试(false);
                通知考试界面考试用时=true;                     
              }
            else if(s.startsWith("读取下一题"))
              {
                String contentTest=读取试题.getTestContent();  
                out.writeUTF("试题内容:"+contentTest);         
                if(通知考试界面考试用时==true)
                   {
                     long time=读取试题.getTime();              
                     out.writeUTF("考试用时:"+time);  
                     通知考试界面考试用时=false;            
                   }
                if(读取试题.get完成考试())
                   {
                     out.writeUTF("考试结束:"); 
                   }
                
              }
            else if(s.startsWith("提交的答案:"))
              {
                String answer=s.substring(s.indexOf(":")+1);  
                读取试题.setSelection(answer);               
              }
            else if(s.startsWith("查看得分"))
              {
                int score=读取试题.getScore();
                String messages=读取试题.getMessages();
                out.writeUTF("分数:"+score+"\n"+messages);
              }
           }
       catch(IOException ee)
           {
              try{
                 socket.close();
                 }
              catch(Exception eee)
                 {
                 }
              System.out.println("客户离开了");
              break;
           }             
     } 
  }
}


