/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package client;

/**
 *
 * @author Administrator
 */
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
public class ChoiceFile extends Panel implements ItemListener,ActionListener,Runnable
{
   Button 得到试题文件=null;
   Choice list=null; 
   Socket  socket=null;
   DataInputStream in=null; 
   DataOutputStream out=null; 
   Thread thread=null;
   boolean success=false, isSelected=false;
   int n=0;
   
   public ChoiceFile()
    {
      得到试题文件=new Button("将试题文件添加到下拉列表中");
      得到试题文件.setEnabled(false);
      得到试题文件.addActionListener(this);
      list=new Choice();
      list.add("**********");
      add(得到试题文件);
      add(list);
      list.addItemListener(this);
      thread=new Thread(this);
    }
  public void setSocketConnection(Socket socket,DataInputStream in,DataOutputStream out)
    {
      this.socket=socket;
      this.in=in;
      this.out=out; 
      try {
            thread.start(); 
          }
      catch(Exception ee)
          {
          }
      if(this.socket!=null)
       {
         得到试题文件.setEnabled(true);
       } 
    }
   public void actionPerformed(ActionEvent e)
    {
         try 
           { 
             out.writeUTF("列出考试文件");
           }
           catch(IOException ee)
           { 
             success=false;
           }
       
    } 
  public void itemStateChanged(ItemEvent e)
    { 
      n=list.getItemCount();
      if(n>=1&&isSelected==true)
        {
          String listItem=list.getSelectedItem();
           try
              {
                out.writeUTF("考试文件的名字:"+listItem);
                out.writeUTF("请通知考试界面考试用时:");
              }
           catch(IOException ee)
              {
              }
        }         
   }
  public String 得到选择的文件名()
   {
    return list.getSelectedItem();
   }
  public void run()
   {
    String s=null;
    list.removeAll();
    while(true)
      { 
        try
           {
             s=in.readUTF();          
              if(s.startsWith("考试文件:"))
                 {
                   String listItem=s.substring(s.indexOf(":")+1);
                   list.add(listItem);
                   isSelected=true;
                 }
               if(s.startsWith("已经全部列出:"))
                 {
                   success=true; 
                   break;
                 }
               
           }
        catch (Exception ee) 
           {
           }   
      }
 }
 public boolean getSuccess()
 { 
   n=list.getItemCount();
   if(n>0&&success==true)
      return true;
   else
      return false;
 }
}
