/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package client;

/**
 *
 * @author Administrator
 */
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.applet.*;
public class ClientBS extends Applet implements ActionListener
{
  Button     开始测试=null;
  Label      提示条1=null,提示条2=null;
  Socket  socket=null;
  DataInputStream in=null; 
  DataOutputStream out=null; 
  ChoiceFile 选择试题文件界面=null;
  ClientTestArea 考试界面=null;
  Panel west, center;
 
  public void init() 
   {
    setLayout(new BorderLayout()); 
    开始测试    =new Button("开始考试");
    开始测试.addActionListener(this);
    选择试题文件界面=new ChoiceFile();
    选择试题文件界面.setVisible(false);
    考试界面=new ClientTestArea();
    考试界面.setVisible(false);
    提示条1=new Label("正在连接到服务器,请稍等...");
    提示条2=new Label("选择一个文件后，单击"+开始测试.getLabel()+"按钮");
    提示条2.setVisible(false);
    Panel H1= new Panel();        
    H1.add(提示条1);
    Panel H2= new Panel(); 
    H2.add(提示条2);
    Panel H3= new Panel(); 
    H3.add(选择试题文件界面);
    west=new Panel();
    center=new Panel();
    west.setLayout(new GridLayout(3,1));
    west.add(H1);
    west.add(H2);
    west.add(H3);
    center.setLayout(new BorderLayout());
    center.add(开始测试,BorderLayout.NORTH);
    center.add(考试界面,BorderLayout.CENTER);
    add(west,BorderLayout.WEST);
    add(center,BorderLayout.CENTER);
    setVisible(true);
    setBounds(60,40,660,460);
    validate();
   }
 public void start()
   {
     if(socket!=null&&in!=null&&out!=null)
        {  try
              {
                socket.close();
                in.close(); 
                out.close();
                考试界面.setVisible(false);
              }
          catch(Exception ee)
              {
               
              }
        }
     try
        {
         socket = new Socket(this.getCodeBase().getHost(), 6666);
         in=new DataInputStream(socket.getInputStream());
         out=new DataOutputStream(socket.getOutputStream());
        }
     catch (IOException ee)
        { 
          提示条1.setText("连接失败");
        }
     if(socket!=null)
        {
         InetAddress address=socket.getInetAddress();
         提示条1.setEnabled(true);
         提示条1.setText("您连接:"+address+"成功");
         选择试题文件界面.setVisible(true);
         选择试题文件界面.validate();
         选择试题文件界面.setSocketConnection(socket,in,out);
         提示条2.setVisible(true);
         west.validate();
         validate();
        } 
   } 
  
 public void stop()
   {
     try 
         {
           socket.close();
         }
     catch(IOException e)
         {
          this.showStatus(e.toString());
         }
   }
 public void actionPerformed(ActionEvent e)
 {  
    if(e.getSource()==开始测试)
      {
         if(选择试题文件界面.getSuccess())
             { 
               考试界面.setSocketConnection(socket,in,out);
               考试界面.setVisible(true);
               考试界面.set试题显示区("你选择了试题:"+选择试题文件界面.得到选择的文件名());
               center.validate();
               validate();
             }
       
      }
    
  }  
}

